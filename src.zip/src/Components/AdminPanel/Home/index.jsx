import * as React from "react";
import SideBar from "../SideBar";
import "./style.css";

function Home() {
  return(
  <div id="HomeMainDiv">
    <div id="homeTop"></div>
    <SideBar />
  </div>
  )
}
export default Home;
