import * as React from "react";
import "./style.css";

function TopBar() {
  return(
  <div id="TopMainDiv">
    <div id="homeTop"></div>
    <SideBar />
  </div>
  )
}
export default TopBar;
